// services/expiredNotif.js - Optimized v2.0
'use strict';

const db = require('../data/db');

const LABEL = {
  SSH:    '⚪ SSH / OpenVPN',
  VMESS:  '🔵 xRay VMess',
  VLESS:  '🟡 xRay VLess',
  TROJAN: '🟠 xRay Trojan',
  ZIVPN:  '🟢 UDP ZivPN'
};

function initNotifTable() {
  db.run(`CREATE TABLE IF NOT EXISTS notif_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER,
    order_id TEXT,
    days_before INTEGER,
    sent_at TEXT,
    UNIQUE(order_id, days_before)
  )`);
  db.run(`CREATE INDEX IF NOT EXISTS idx_notif_order ON notif_log(order_id, days_before)`);
}

function sudahDikirim(orderId, daysBefore, callback) {
  db.get(
    'SELECT id FROM notif_log WHERE order_id=? AND days_before=?',
    [orderId, daysBefore],
    (err, row) => callback(!!row)
  );
}

function tandaiTerkirim(chatId, orderId, daysBefore) {
  db.run(
    "INSERT OR IGNORE INTO notif_log (chat_id, order_id, days_before, sent_at) VALUES (?, ?, ?, datetime('now','localtime'))",
    [chatId, orderId, daysBefore]
  );
}

function kirimNotif(bot, row, days) {
  const label = LABEL[row.product_type] || row.product_type;
  const emoji = days === 1 ? '🔴' : '🟡';
  const expStr = row.expired_at ? row.expired_at.slice(0, 10) : '-';

  bot.sendMessage(row.chat_id,
`${emoji} <b>PERINGATAN! Akun akan expired!</b>

${label}
👤 Username : <code>${row.username || '-'}</code>
📅 Expired  : <b>${expStr}</b>
⏳ Sisa     : <b>${days} hari lagi</b>

Segera perpanjang agar akun tidak mati!`,
    {
      parse_mode: 'HTML',
      reply_markup: {
        inline_keyboard: [
          [{ text: '🔄 Extend Sekarang', callback_data: 'renew_menu' }],
          [{ text: '🛒 Ke Menu Utama',   callback_data: 'menu_back'  }]
        ]
      }
    }
  ).catch(() => {});
}

function cekDanKirim(bot) {
  [3, 1].forEach(days => {
    const sql = `
      SELECT t.chat_id, t.order_id, t.product_type, t.username, t.expired_at
      FROM transactions t
      WHERE t.status = 'completed'
        AND t.expired_at IS NOT NULL AND t.expired_at != ''
        AND t.product_type NOT IN ('', 'TOPUP')
        AND t.product_type NOT LIKE 'TRIAL%'
        AND date(t.expired_at) = date('now', 'localtime', '+${days} days')
    `;

    db.all(sql, [], (err, rows) => {
      if (err || !rows?.length) return;

      rows.forEach((row, i) => {
        sudahDikirim(row.order_id, days, (sudah) => {
          if (sudah) return;
          setTimeout(() => {
            kirimNotif(bot, row, days);
            tandaiTerkirim(row.chat_id, row.order_id, days);
          }, i * 300);
        });
      });
    });
  });
}

function startExpiredNotif(bot) {
  initNotifTable();
  setTimeout(() => cekDanKirim(bot), 15000);
  setInterval(() => cekDanKirim(bot), 60 * 60 * 1000);
  console.log('[expiredNotif] ✅ Expired notif aktif (cek tiap 1 jam)');
}

module.exports = { startExpiredNotif };
